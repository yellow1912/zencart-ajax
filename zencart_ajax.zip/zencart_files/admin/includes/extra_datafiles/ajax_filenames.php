<?php
	define('TABLE_AJAX_BLOCKS', DB_PREFIX.'ajax_blocks');
	